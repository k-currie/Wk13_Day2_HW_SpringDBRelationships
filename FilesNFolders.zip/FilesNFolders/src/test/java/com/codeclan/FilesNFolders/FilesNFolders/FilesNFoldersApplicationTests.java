package com.codeclan.FilesNFolders.FilesNFolders;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FilesNFoldersApplicationTests {

	@Test
	void contextLoads() {
	}

}
